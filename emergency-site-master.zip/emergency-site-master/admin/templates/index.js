import Post from '/admin/templates/post.js'

CMS.registerPreviewTemplate('posts', Post)
CMS.registerPreviewStyle('/static/styles/style.css')
